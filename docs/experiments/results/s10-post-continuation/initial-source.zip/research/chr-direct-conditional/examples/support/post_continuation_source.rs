use chr_syntax::{Answer, Goal, Query, Rule, Term, Var, and, atom, c, eq, or, t, v};
pub const FAMILIES: [&str; 3] = ["common", "independent", "early"];
fn depth(n: usize) -> Term {
    (0..n).fold(atom("z"), |x, _| t("s", [x]))
}
pub fn rules(family: &str, k: usize, history: bool) -> Vec<Rule> {
    assert!(FAMILIES.contains(&family));
    let mut body = vec![];
    for i in 0..k {
        body.push(c(&format!("choose{i}"), [v(10 + i as u64)]).into());
    }
    body.push(c("emit", [v(2)]).into());
    let mut n = v(0);
    if family == "independent" {
        for i in 0..k {
            let next = v(30 + i as u64);
            body.push(c("extend", [v(10 + i as u64), n, next.clone()]).into());
            n = next;
        }
    }
    body.push(c("consume", [n, v(2), v(3)]).into());
    body.push(eq(
        v(1),
        t(
            "answer",
            [
                t(
                    "colors",
                    (0..k).map(|i| v(10 + i as u64)).collect::<Vec<_>>(),
                ),
                v(3),
            ],
        ),
    ));
    let mut rules = vec![
        Rule::simplify("start", [c("start", [v(0), v(1)])], and(body)),
        Rule::simplify(
            "emit",
            [c("emit", [v(0)])],
            and([c("token", [v(0)]).into(), eq(v(0), atom("a"))]),
        ),
        Rule::simplify(
            "consume",
            [c("consume", [v(0), v(1), v(2)]), c("token", [v(1)])],
            c("run", [v(0), v(2)]).into(),
        ),
        Rule {
            name: "step".into(),
            kept: vec![c("permit", [])],
            removed: vec![c("run", [t("s", [v(0)]), v(1)]), c("fuel", [])],
            guards: vec![],
            body: c("run", [v(0), v(1)]).into(),
        },
        Rule::simplify(
            "done",
            [c("run", [atom("z"), v(0)])],
            and([c("fresh", [v(1), v(1)]).into(), eq(v(0), t("done", [v(1)]))]),
        ),
        // Establish the passive resource signature without enabling its consumer.
        Rule::simplify(
            "sink",
            [c("sink", [v(0)]), c("fresh", [v(1), v(2)])],
            eq(v(0), atom("ok")),
        ),
    ];
    if family == "independent" {
        rules.extend([
            Rule::simplify(
                "extend-a",
                [c("extend", [atom("a"), v(0), v(1)])],
                eq(v(1), v(0)),
            ),
            Rule::simplify(
                "extend-b",
                [c("extend", [atom("b"), v(0), v(1)])],
                eq(v(1), t("s", [v(0)])),
            ),
        ]);
    }
    for i in 0..k {
        rules.push(Rule::simplify(
            &format!("choose{i}"),
            [c(&format!("choose{i}"), [v(0)])],
            or(
                eq(v(0), atom("a")),
                if family == "early" && i == 0 {
                    Goal::Fail
                } else {
                    eq(v(0), atom("b"))
                },
            ),
        ));
    }
    if history {
        rules.push(Rule::propagate(
            "permit-history",
            [c("permit", [])],
            c("mark", []).into(),
        ));
    }
    rules
}
pub fn query(family: &str, k: usize, d: usize, seed: usize, reverse: bool) -> Query {
    let base = 100 + 1000 * seed as u64;
    let mut constraints = vec![
        c("start", [depth(d), v(base)]),
        c("permit", []),
        c("query", [atom(&format!("q{seed}"))]),
    ];
    constraints.extend((0..d + if family == "independent" { k } else { 0 }).map(|_| c("fuel", [])));
    if reverse {
        constraints.reverse();
    }
    Query {
        constraints,
        outputs: vec![("result".into(), Var(base))],
    }
}
pub fn expected(family: &str, k: usize, seed: usize, history: bool) -> Vec<Answer> {
    (0..1usize << k)
        .filter(|bits| !(family == "early" && k > 0 && bits & 1 != 0))
        .map(|bits| {
            let mut residual = vec![
                c("permit", []),
                c("query", [atom(&format!("q{seed}"))]),
                c("fresh", [v(9000), v(9000)]),
            ];
            if history {
                residual.push(c("mark", []));
            }
            if family == "independent" {
                residual.extend((0..k - bits.count_ones() as usize).map(|_| c("fuel", [])));
            }
            Answer {
                outputs: vec![(
                    "result".into(),
                    t(
                        "answer",
                        [
                            t(
                                "colors",
                                (0..k)
                                    .map(|i| atom(if bits & (1 << i) == 0 { "a" } else { "b" }))
                                    .collect::<Vec<_>>(),
                            ),
                            t("done", [v(9000)]),
                        ],
                    ),
                )],
                residual,
            }
        })
        .collect()
}
pub fn explicit_steps(family: &str, k: usize, d: usize) -> usize {
    if family == "early" && k > 0 {
        (1 << (k - 1)) * d
    } else if family == "independent" && k > 0 {
        (1 << k) * d + k * (1 << (k - 1))
    } else {
        (1 << k) * d
    }
}
