//! Experimental direct conditional CHR substrate.
pub mod support;

pub mod births;
pub mod equality;

pub mod matching;

pub mod resources;

pub mod engine;

#[cfg(feature = "prefix-join")]
mod prefix_join;
